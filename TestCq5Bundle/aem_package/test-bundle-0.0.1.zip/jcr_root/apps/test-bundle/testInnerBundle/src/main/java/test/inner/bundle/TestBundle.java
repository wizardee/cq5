package test.inner.bundle;

import db.driver.mariadb.DbConnection;
import db.utils.TestUtils;

/**
 * TestBundle class for testing.
 */
public class TestBundle {

    public static String testBundle() {

        try {

            DbConnection.testConnection();
            TestUtils.sayHello1("UNIVISTA");

        }catch(Exception e) {
            e.printStackTrace();
        }
        return "Hello 555.";
    }
}